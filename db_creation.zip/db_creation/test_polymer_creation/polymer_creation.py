import rdkit
from rdkit import Chem
from rdkit.Chem import AllChem
from pysoftk.topologies.diblock import *
from pysoftk.format_printers.format_mol import *
import os
import itertools

current_directory = os.getcwd()
donor_path = os.path.join(current_directory, "donor")
bridge_path = os.path.join(current_directory, "bridge")
acceptor_path = os.path.join(current_directory, "acceptor")

donor_files = [f for f in os.listdir(donor_path) if os.path.isfile(os.path.join(donor_path, f))]
bridge_files = [f for f in os.listdir(bridge_path) if os.path.isfile(os.path.join(bridge_path, f))]
acceptor_files = [f for f in os.listdir(acceptor_path) if os.path.isfile(os.path.join(acceptor_path, f))]

all_combinations = itertools.product(donor_files, bridge_files, acceptor_files)

for i, (donor_file, bridge_file, acceptor_file) in enumerate(all_combinations):
    donor_mol = Chem.MolFromMolFile(os.path.join(donor_path, donor_file),removeHs=False, sanitize=False)
    bridge_mol = Chem.MolFromMolFile(os.path.join(bridge_path, bridge_file), removeHs=False, sanitize=False)
    acceptor_mol = Chem.MolFromMolFile(os.path.join(acceptor_path, acceptor_file),removeHs=False, sanitize=False)
    mol_combination = [donor_mol, bridge_mol, acceptor_mol]

    string="DBA"
    patt = Pt(string, mol_combination, "Br").pattern_block_poly()

    # Create a unique filename
    unique_filename = f"combination_{i+1}.xyz"

    # Print the molecules to the XYZ file with the unique name
    Fmt(patt).xyz_print(unique_filename)


